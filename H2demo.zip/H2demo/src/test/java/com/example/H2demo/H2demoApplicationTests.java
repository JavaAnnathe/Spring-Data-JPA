package com.example.H2demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2demoApplicationTests {

	@Test
	void contextLoads() {
	}

}
