package com.annathe.ormlearn;

import java.util.Optional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.annathe.ormlearn.model.Message;
import com.annathe.ormlearn.repository.MessageRepository;

@SpringBootApplication
public class SpringDataJpaDemoApplication {
	
	private static MessageRepository messageRepository; 

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringDataJpaDemoApplication.class, args);
		
		messageRepository = context.getBean(MessageRepository.class); 
		
		testFindById(3);
		
	}

public static void testFindById(Integer id) {
		
		Optional<Message> messageOptional =messageRepository.findById(id);
		
	Message message = messageOptional.get();
		
		System.out.println("Message name: "+message.getText());
		
		
		
		
	}


}
